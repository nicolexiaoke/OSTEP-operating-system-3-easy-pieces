-- DROP TABLE IF EXISTS user;
-- DROP TABLE IF EXISTS post;

CREATE TABLE User (
  u_id INTEGER PRIMARY KEY AUTOINCREMENT,
  pid char(20),
  u_name varchar(10) NOT NULL,
  u_sex int,
  u_birth date,
  u_tel char(11),
  u_addr varchar(30),
  u_password varchar(20) NOT NULL
);

CREATE TABLE Loan (
  l_id INTEGER PRIMARY KEY AUTOINCREMENT,
  a_id INTEGER,
  loan_total float,
  l_start TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  repay_total float,
  repay_per_month float,
  repay_month int,
  FOREIGN KEY (a_id) REFERENCES Account (a_id)
);


CREATE TABLE Account (
  a_id INTEGER PRIMARY KEY AUTOINCREMENT,
  u_id INTEGER,
  balance float,
  a_type int,
  a_status int,
  creation_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  l_id int,
  FOREIGN KEY (u_id) REFERENCES user (u_id),
  FOREIGN KEY (l_id) REFERENCES Loan (l_id)
);

