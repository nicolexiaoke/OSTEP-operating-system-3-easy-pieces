SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:lxk949017@localhost:3306/onlinebank'
# 'mysql+pymysql://用户名称:密码@localhost:端口/数据库名称'
SQLALCHEMY_TRACK_MODIFICATIONS = False
