from flask import Flask
from flask import render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date

app = Flask(__name__)
app.config.from_object('config')
db = SQLAlchemy(app, use_native_unicode='utf8')

import config, model

#亲爱的后台女性同袍们，你们需要看的是financeForm、loanForm、login、transfer四个HTML
#加油(ง •_•)ง
class Users(db.Model):
    """用户"""
    __tablename__ = 'Users'
    #__table_args__ = {'mysql_engine': 'InnoDB'}  # 支持事务操作和外键
    u_id = db.Column(db.Integer, doc = '客户号', primary_key=True)
    pid = db.Column(db.String(18),doc = '身份证号', nullable=False, unique=True)
    u_name = db.Column(db.String(10), doc='姓名', nullable=True)
    u_sex = db.Column(db.Integer, doc='性别', nullable=True)
    u_birth = db.Column(db.DateTime, doc='出生年月日',  nullable=True)
    u_tel = db.Column(db.String(11), doc='电话', nullable=True)
    u_addr = db.Column(db.String(30), doc='住址', nullable=True)
    u_password = db.Column(db.String(20), doc='密码', nullable=False)

class Bank(db.Model):
    """银行"""
    __tablename__ = 'Bank'
    bk_id = db.Column(db.Integer, doc = '银行号', primary_key=True)
    bk_name = db.Column(db.String(20),doc = '开户行', nullable=False,default='人大分行')
    total_money = db.Column(db.Float, doc='总金额', nullable=False)


class Accounts(db.Model):
    """账户"""
    __tablename__ = 'Accounts'
    a_id = db.Column(db.Integer, doc = '账户号', primary_key=True)
    u_id = db.Column(db.Integer, db.ForeignKey('Users.u_id'),doc = '客户号', nullable=False)
    balance = db.Column(db.Float, doc='余额', nullable=False)
    a_type = db.Column(db.Integer, doc='账户类型', nullable=False) #信用卡：1；
    a_state = db.Column(db.Integer, doc='账户状态',  nullable=False)#激活：1；未激活：0；
    creation_date = db.Column(db.DateTime, doc='开户时间', default = datetime.now)
    bk_id = db.Column(db.Integer, db.ForeignKey('Bank.bk_id'),doc='开户银行号', nullable=True)
    l_id = db.Column(db.Integer, doc='贷款号', nullable=True)

class Transaction(db.Model):
    """交易"""
    __tablename__ = 'Transaction'
    t_id = db.Column(db.Integer, doc = '交易号', primary_key=True)
    hka_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '汇款方账户号', nullable=False)
    ska_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '收款方账户号', nullable=False)
    t_money = db.Column(db.Float, doc='交易金额', nullable=False)
    t_time = db.Column(db.DateTime, doc='操作时间', default = datetime.now, nullable=False)
    t_type = db.Column(db.Integer, doc='交易类型',  nullable=False)  #账户间转账：1；
    t_channel = db.Column(db.String(20), doc='交易渠道', nullable=False)
    t_str = db.Column(db.String(50),doc='交易备注', nullable=True)


class Loan(db.Model):
    """贷款"""
    __tablename__ = 'Loan'
    l_id = db.Column(db.Integer, doc = '贷款号', primary_key=True)
    a_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '账户号', nullable=False)
    loan_total = db.Column(db.Float, doc='贷款总金额', nullable=False)
    l_start = db.Column(db.DateTime, doc='贷款时间', default = datetime.now, nullable=False)
    repay_total = db.Column(db.Float, doc='还款总金额',  nullable=False)
    repay_per_month = db.Column(db.Float, doc='每月还款金额', nullable=False)
    repay_month = db.Column(db.Integer,doc='还需还款月份', nullable=True)

class FinanceProducts(db.Model):
    '''理财产品'''
    _tablename_ = 'FinanceProducts'
    fp_id = db.Column(db.Integer,doc='理财产品号', primary_key=True)
    fp_account = db.Column(db.String(20),doc='公司账户号',nullable=False)
    fp_name = db.Column(db.String(20),doc='理财产品名称',nullable=False)
    profit = db.Column(db.Float,doc='分红率/（每月）',nullable=False)
    note = db.Column(db.String(50),doc='备注信息',nullable=True)

class Finance(db.Model):
    '''理财'''
    _tablename_ = 'Finance'
    a_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc='账户号', primary_key=True)
    # fp_id = db.Column(db.Integer, db.ForeignKey('FinanceProducts.fp_id'),doc='理财产品号',nullable=False, primary_key=True)
    fp_id = db.Column(db.Integer,doc='理财产品号',nullable=False, primary_key=True)
    f_amount = db.Column(db.Float,doc='本金',nullable=False)
    t_id = db.Column(db.Integer, db.ForeignKey('Transaction.t_id'), doc = '交易号', nullable=False)
    f_start = db.Column(db.DateTime,doc='开始投资时间',nullable=False, default = datetime.now)
    f_income = db.Column(db.Float,doc='累计收益',nullable=False)

db.create_all()
bank=Bank(bk_name = '人大分行',total_money = 10000000000)
db.session.add(bank)
user=Users(pid='440000198810299980',u_name='丁一',u_password=000000)
db.session.add(user)
account=Accounts(a_id=1111, u_id = 1,balance=10000, a_type=1, a_state=1)
db.session.add(account)
account=Accounts(a_id=2222, u_id = 1,balance=100, a_type=1, a_state=1)
db.session.add(account)
account=Accounts(a_id=3333, u_id = 1,balance=50000, a_type=1, a_state=1)
db.session.add(account)
account=Accounts(a_id=4444, u_id = 1,balance=8000, a_type=1, a_state=1)
db.session.add(account)

db.session.commit()
# bank=Bank.query.filter(Bank.bk_id == 3).first()
# db.session.delete(bank)
# db.session.commit()

@app.route('/')
def hello_world():
    return render_template('login.html')

@app.route('/userlogin')
def getlogin():
    return render_template('index.html')

@app.route('/table')
def get_table():
    return render_template('table.html')

# @app.route('/transfer')
# def get_transfer():
#     return render_template('transfer.html')

@app.route('/transfer',methods=['GET','POST'])
def get_transfer():
    if request.method=='GET':
        return render_template('transfer.html')
    if request.method == 'POST':
        initiator_card_number=request.form.get('transfer_cardnum_select')
        receiver_card_number=request.form.get('receiver_card_number')
        if not receiver_card_number:
            error = 'receiver\'s card number is required.'
        trasfer_amount=request.form.get('trasfer_amount')
        if not trasfer_amount:
            error = 'trasfer amount is required.'
        trans_notes=request.form.get('trans_notes')

        trans=Transaction(hka_id=initiator_card_number,ska_id=receiver_card_number,\
                          t_money=trasfer_amount,t_type=1,t_channel='网上银行转账')
        db.session.add(trans)
        hk_account = Accounts.query.filter(Accounts.a_id == initiator_card_number).first()
        hk_account.balance -= trasfer_amount   #此处没有算手续费
        sk_account = Accounts.query.filter(Accounts.a_id == receiver_card_number).first()
        sk_account.balance += trasfer_amount
        db.session.commit()
        return redirect(url_for('transfer'))


@app.route('/loanProduct')
def get_loanProduct():
    return render_template('loanProduct.html')

@app.route('/financeProduct')
def get_financeProduct():
    return render_template('financeProduct.html')

@app.route('/financeForm')
def get_financeForm():
    return render_template('financeForm.html')

@app.route('/financeDetail')
def get_financeDetail():
    return render_template('financeDetail.html')

@app.route('/loanForm')
def get_loanForm():
    return render_template('loanForm.html')

@app.route('/loanDetail')
def get_loanDetail():
    return render_template('loanDetail.html')

if __name__ == '__main__':
    app.run()
