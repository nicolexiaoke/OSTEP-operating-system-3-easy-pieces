from operator import or_, and_
from flask import Flask
from flask import render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date

app = Flask(__name__)
app.config.from_object('config')
db = SQLAlchemy(app, use_native_unicode='utf8')

import config, model
cur_user_id = 4

#亲爱的后台女性同袍们，你们需要看的是financeForm、loanForm、login、transfer四个HTML
#加油(ง •_•)ง
class Users(db.Model):
    """用户"""
    __tablename__ = 'Users'
    #__table_args__ = {'mysql_engine': 'InnoDB'}  # 支持事务操作和外键
    u_id = db.Column(db.Integer, doc = '客户号', primary_key=True)
    pid = db.Column(db.String(18),doc = '身份证号', nullable=False, unique=True)
    u_name = db.Column(db.String(10), doc='姓名', nullable=True)
    u_sex = db.Column(db.Integer, doc='性别', nullable=True)
    u_birth = db.Column(db.DateTime, doc='出生年月日',  nullable=True)
    u_tel = db.Column(db.String(11), doc='电话', nullable=True)
    u_addr = db.Column(db.String(30), doc='住址', nullable=True)
    u_password = db.Column(db.String(20), doc='密码', nullable=False)

class Bank(db.Model):
    """银行"""
    __tablename__ = 'Bank'
    bk_id = db.Column(db.Integer, doc = '银行号', primary_key=True)
    bk_name = db.Column(db.String(20),doc = '开户行', nullable=False,default='人大分行')
    total_money = db.Column(db.Float, doc='总金额', nullable=False)


class Accounts(db.Model):
    """账户"""
    __tablename__ = 'Accounts'
    a_pk = db.Column(db.Integer, doc = '账户主键', primary_key=True)
    a_id = db.Column(db.Integer, doc = '账户号', unique=True)
    u_id = db.Column(db.Integer, db.ForeignKey('Users.u_id'),doc = '客户号', nullable=False)
    balance = db.Column(db.Float, doc='余额', nullable=False)
    a_type = db.Column(db.Integer, doc='账户类型', nullable=False) #信用卡：1；银行账户：0；公司账户：2
    a_state = db.Column(db.Integer, doc='账户状态',  nullable=False)#绑定：1；未绑定：0；
    creation_date = db.Column(db.DateTime, doc='开户时间', default = datetime.now)
    bk_id = db.Column(db.Integer, db.ForeignKey('Bank.bk_id'),doc='开户银行号', nullable=True)
    l_id = db.Column(db.Integer, doc='贷款号', nullable=True)

class Transaction(db.Model):
    """交易"""
    __tablename__ = 'Transaction'
    t_id = db.Column(db.Integer, doc = '交易号', primary_key=True)
    hka_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '汇款方账户号', nullable=False)
    ska_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '收款方账户号', nullable=False)
    t_money = db.Column(db.Float, doc='交易金额', nullable=False)
    t_time = db.Column(db.DateTime, doc='操作时间', default = datetime.now, nullable=False)
    t_type = db.Column(db.Integer, doc='交易类型',  nullable=False)  #账户间转账：1； 贷款：2
    t_channel = db.Column(db.String(20), doc='交易渠道', nullable=False)
    t_str = db.Column(db.String(50),doc='交易备注', nullable=True)


class Loan(db.Model):
    """贷款"""
    __tablename__ = 'Loan'
    l_id = db.Column(db.Integer, doc = '贷款号', primary_key=True)
    a_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc = '账户号', nullable=False)
    loan_total = db.Column(db.Float, doc='贷款总金额', nullable=False)
    l_start = db.Column(db.DateTime, doc='贷款时间', default = datetime.now, nullable=False)
    repay_total = db.Column(db.Float, doc='还款总金额',  nullable=False)
    repay_per_month = db.Column(db.Float, doc='每月还款金额', nullable=False)
    repay_month = db.Column(db.Integer,doc='还需还款月份', nullable=True)

class FinanceProducts(db.Model):
    '''理财产品'''
    _tablename_ = 'FinanceProducts'
    fp_id = db.Column(db.Integer,doc='理财产品号', primary_key=True)
    fp_account = db.Column(db.String(20),doc='公司账户号',nullable=False)
    fp_name = db.Column(db.String(20),doc='理财产品名称',nullable=False)
    profit = db.Column(db.Float,doc='分红率/（每月）',nullable=False)
    note = db.Column(db.String(50),doc='备注信息',nullable=True)

class Finance(db.Model):
    '''理财'''
    _tablename_ = 'Finance'
    a_id = db.Column(db.Integer, db.ForeignKey('Accounts.a_id'),doc='账户号', primary_key=True)
    # fp_id = db.Column(db.Integer, db.ForeignKey('FinanceProducts.fp_id'),doc='理财产品号',nullable=False, primary_key=True)
    fp_id = db.Column(db.Integer,doc='理财产品号',nullable=False, primary_key=True)
    f_amount = db.Column(db.Float,doc='本金',nullable=False)
    t_id = db.Column(db.Integer, db.ForeignKey('Transaction.t_id'), doc = '交易号', nullable=False)
    f_start = db.Column(db.DateTime,doc='开始投资时间',nullable=False, default = datetime.now)
    f_income = db.Column(db.Float,doc='累计收益',nullable=False)

######################################建立数据库并灌入数据##############################################

# db.create_all()
# bank=Bank(bk_name = '人大分行',total_money = 10000000000)
# db.session.add(bank)
#
# user=Users(pid='银行',u_name='人大分行',u_password='rendafenhang')
# db.session.add(user)
# user=Users(pid='理财公司',u_name='招商证券',u_password='zhaoshangzhengquan')
# db.session.add(user)
# user=Users(pid='100000000000000000',u_name='王一',u_password='123456')
# db.session.add(user)
# user=Users(pid='200000000000000000',u_name='张二',u_password='234561')
# db.session.add(user)

# account=Accounts(a_id=1000000000, u_id = 1, balance=10000000000, a_type=0, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1900000001, u_id = 2, balance=500000000, a_type=2, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1900000002, u_id = 2, balance=200000000, a_type=2, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000031, u_id = 3, balance=18000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000032, u_id = 3, balance=9000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000033, u_id = 3, balance=50000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000041, u_id = 4, balance=6000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000042, u_id = 4, balance=20000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000043, u_id = 4, balance=75000, a_type=1, a_state=1)
# db.session.add(account)
# account=Accounts(a_id=1000000044, u_id = 4, balance=75000, a_type=1, a_state=0)
# db.session.add(account)
#
# fproducts1=FinanceProducts(fp_account = 1900000001,fp_name ='基金A',profit = 0.1, note='' )
# db.session.add(fproducts1)
# fproducts1=FinanceProducts(fp_account = 1900000002,fp_name ='基金B',profit = 0.3, note='' )
# db.session.add(fproducts1)


# db.session.commit()

####################################################################################

@app.route('/')
def hello_world():
    #mytransfer={'money':1,'receive_name':1,'receive_account':1,'pay_account':1,'method':1}
    #return render_template('success.html',transfer=mytransfer)
    return render_template('login.html')

@app.route('/register')
def register():
    print('register')
    return render_template('register.html')

@app.route('/register/info',methods=["POST"])
def get_register():
    print('get register')
    inputname = request.form.get('inputname')
    inputid = request.form.get('inputid')
    inputpassword = request.form.get('inputpassword')
    inputrepassword = request.form.get('inputrepassword')
    #添加到数据库
    newuser=Users(u_name=inputname,pid = inputid, u_password = inputpassword )
    db.session.add(newuser)
    db.session.commit()
    return "new user created."
    

@app.route('/email')
def get_email():
    global cur_user_id
    curuser = Users.query.filter(Users.u_id == cur_user_id).first()
    accountlist = Accounts.query.filter(and_((Accounts.u_id == cur_user_id),(Accounts.a_state == 1))).all()
    for i in range(len(accountlist)):
        print(accountlist[i],type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    myuser={'name':curuser.u_name,'ID':curuser.pid,'bir':curuser.u_birth,'tel':curuser.u_tel,'add':curuser.u_addr,'card':accountlist}

    myletter=["你好，主人","我是您的小管家","您下次还款时间为2020-05-08","您的理财产品将在一周内分红"]
    mytask=["赢积分送大礼","您的年终贷款大礼来啦"]
    mymail=["您下次还款时间为2020-05-08","您的理财产品将在一周内分红"]
    myfellow=["资深分析师李小可","您的高级顾问胡雨阳"]
    return render_template('email.html',user=myuser,letter=myletter,task=mytask,mail=mymail,fellow=myfellow)

@app.route('/userlogin',methods=['POST'])
def login():
    global cur_user_id
    inputid = request.form.get('inputid')
    inputpassword = request.form.get('inputpassword')

    if not inputid:
        error = 'username is required.'
        return render_template('login.html')
    if not inputpassword:
        error = 'password is required.'
        return render_template('login.html')

    inputuser = Users.query.filter(Users.pid == inputid).first()
    if not inputuser:
        return render_template('login.html')
    #修改全局变量
    cur_user_id = inputuser.u_id
    print(inputuser,type(inputuser))
    print(inputuser.u_password,inputpassword)
    if inputuser.u_password != inputpassword:
        error = 'password does not match!'
        return render_template('login.html')
    else:
        return render_template('index.html')

@app.route('/userlogin')
def getlogin():
    return render_template('index.html')

@app.route('/index')
def get_index():
    return render_template('index.html')

@app.route('/addcard')
def get_addcard():
    #加卡
    return render_template('center.html')

@app.route('/search',methods=["GET"])
def get_search():
    global cur_user_id
    print('intosearch',cur_user_id)
    accountlist = Accounts.query.filter(Accounts.u_id == cur_user_id).all()
    for i in range(len(accountlist)):
        print(accountlist[i].u_id,type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    
    trans_query = Transaction.query.filter(or_(Transaction.hka_id.in_(accountlist),Transaction.ska_id.in_(accountlist) )).all()
    # trans_query = Transaction.query.filter(Transaction.hka_id.in_(accountlist)).all()
    print(trans_query,type(trans_query))
    hkcard = []
    skcard = []
    time = []
    kind = [ ]
    path = []
    money = []
    for i in range(len(trans_query)):
        print(trans_query[i])
        hkcard.append(trans_query[i].hka_id)
        skcard.append(trans_query[i].ska_id)
        time.append(trans_query[i].t_time)
        kind.append(trans_query[i].t_channel)
        money.append(trans_query[i].t_money)

    print('search')
    return render_template('search.html', hkcard=hkcard,skcard=skcard,time=time,kind=kind,money=money)

@app.route('/table')
def get_table():
    global cur_user_id
    curuser = Users.query.filter(Users.u_id == cur_user_id).first()
    accountlist = Accounts.query.filter(and_((Accounts.u_id == cur_user_id),(Accounts.a_state == 1))).all()
    for i in range(len(accountlist)):
        print(accountlist[i],type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    userinfo={'name':curuser.u_name,'ID':curuser.pid,'bir':curuser.u_birth,'tel':curuser.u_tel,'add':curuser.u_addr,'card':accountlist}
    return render_template('center.html',user=userinfo)

@app.route('/addcard/info', methods=['post'])
def add_card():    
    #如果接收到绑定需求，则更新数据库
    print("ok")
    binding_card_number = int(request.form.get('binding_card_number'))
    print(binding_card_number)
    if binding_card_number:
        if_successful = Binding(int(binding_card_number))
        if if_successful == 'card not exists!!!!!':
            print('bind fail1')
            return 'binding card error--card not exists!!!!!'
        elif if_successful == 'card already binded!!!!!':
            print('bind fail2')
            return 'binding card error--already binded!!!!!'
    return render_template("center.html")

def Binding(binding_card_number):
    print('into binding')
    '''绑定卡即修改status
    1. 已绑定
    2. 存在未绑定
    3. 不存在该卡
    '''
    card = Accounts.query.filter(Accounts.a_id == binding_card_number).first()
    #不存在该卡
    if not card:
        return 'card not exists!!!!!'
    #已绑定
    if card.a_state == 1:
        return 'card already binded!!!!!'
    #存在未绑定
    if card.a_state == 0:
        print(type(binding_card_number), binding_card_number)
        card.a_state = 1 
        db.session.commit()
        return 'sccessfully binded!'
    


@app.route('/transfer')
def get_transfer():
    #查找数据
    accountlist = Accounts.query.filter(and_((Accounts.u_id == cur_user_id),(Accounts.a_state == 1))).all()
    for i in range(len(accountlist)):
        print(accountlist[i],type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    print(accountlist)
    return render_template('transfer.html',data='后台显示到前端',list=accountlist)

@app.route('/postinfo',methods=['POST'])
def post_transfer():
    initiator_card_number = int(request.form.get('transfer_cardnum_select'))
    receiver_card_number = int(request.form.get('receiver_card_number'))

    if not receiver_card_number:
        error = 'receiver\'s card number is required.'
    transfer_amount = float(request.form.get('transfer_amount'))
    if not transfer_amount:
        error = 'transfer amount is required.'
    trans_notes = request.form.get('trans_notes')

    print(initiator_card_number,receiver_card_number,trans_notes,transfer_amount)

    trans = Transaction(hka_id=initiator_card_number, ska_id=receiver_card_number, \
                        t_money=transfer_amount, t_type=1, t_channel='网上银行转账')
    db.session.add(trans)
    hk_account = Accounts.query.filter(Accounts.a_id == initiator_card_number).first()
    hk_account.balance = hk_account.balance -transfer_amount  # 此处没有算手续费
    sk_account = Accounts.query.filter(Accounts.a_id == receiver_card_number).first()
    sk_account.balance = sk_account.balance + transfer_amount
    db.session.commit()

    mytransfer={'money':1,'receive_name':1,'receive_account':1,'pay_account':1,'method':1}
    return render_template('success.html',transfer=mytransfer)

@app.route('/loanProduct')
def get_loanProduct():
    return render_template('loanProduct.html')

# @app.route('/loanProduct')
# def get_index():
#     return render_template('loanProduct.html')

@app.route('/financeProduct')
def get_financeProduct():
    return render_template('financeProduct.html')

@app.route('/financeForm')
def get_financeForm():
    #查找数据
    accountlist = Accounts.query.filter(and_((Accounts.u_id == cur_user_id),(Accounts.a_state == 1))).all()
    for i in range(len(accountlist)):
        print(accountlist[i],type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    print(accountlist)
    productlist=FinanceProducts.query.filter().all()
    for i in range(len(productlist)):
        productlist[i]=productlist[i].fp_name
    print(productlist)
    return render_template('financeForm.html',data='后台显示到前端',list1=accountlist,list2=productlist)


@app.route('/financeForm/postinfo', methods=['POST'])
def post_financeForm():
    finance_card = int(request.form.get('financeForm-card-select'))  # 理财账户号
    product_name = request.form.get('financeForm-kind-select')  # 理财产品
    finance_amount = float(request.form.get("finance-amount"))  # 理财金额
    trans_notes = request.form.get("finance-amount")  # 其他信息

    company_cardlist = FinanceProducts.query.filter(FinanceProducts.fp_name == product_name).all()
    company_card = int(company_cardlist[0].fp_account)
    finance_id = company_cardlist[0].fp_id
    trans = Transaction(hka_id=finance_card, ska_id=company_card, \
                        t_money=finance_amount, t_type=2, t_channel='网上银行', t_str='理财产品购买')
    db.session.add(trans)
    trans = Transaction.query.filter(Transaction.hka_id == finance_card, Transaction.ska_id == company_card).first()
    tid = trans.t_id
    finance = Finance(a_id=finance_card, fp_id=finance_id, f_amount=finance_amount, t_id=tid, f_income=0)
    db.session.add(finance)

    # print('&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&*&\n', finance_card, company_card)
    finance_account = Accounts.query.filter(Accounts.a_id == finance_card).first()
    print(finance_card, finance_account)
    finance_account.balance = finance_account.balance - finance_amount
    print(company_card)
    company_account = Accounts.query.filter(Accounts.a_id == company_card).first()
    company_account.balance = company_account.balance + finance_amount
    print(company_card, company_account)
    db.session.commit()
    '''稍稍一下这个函数？让它变得在一个公司有两个不同账户的话支撑不同理财产品的时候，能够给正确的那个账户加钱！'''
    # print(financeForm_card_select,financeForm_kind_select,finance_amount,trans_notes)
    return "ok"

@app.route('/financeDetail')
def get_financeDetail():
    return render_template('financeDetail.html')

@app.route('/loanForm')
def get_loanForm():
    # 查找数据
    accountlist = Accounts.query.filter(and_((Accounts.u_id == cur_user_id),(Accounts.a_state == 1))).all()
    for i in range(len(accountlist)):
        print(accountlist[i], type(accountlist[i].a_id))
        accountlist[i] = accountlist[i].a_id
    print(accountlist)
    return render_template('loanForm.html', data='后台显示到前端', list=accountlist)

@app.route('/loanDetail')
def get_loanDetail():
    return render_template('loanDetail.html')

@app.route('/loanForm/postinfo',methods=['POST'])
def post_loanForm():
    if request.method == 'POST':
        card_num = int(request.form.get('loanForm-card-select'))
        loan_money = float(request.form.get('loan-amount'))
        if loan_money < 30000 or loan_money > 1000000:  #工资贷额度不在3-100万
            error = 'the loan amount must be in 3-100w'

        trans = Transaction(hka_id=1000000000, ska_id=card_num, \
                            t_money=loan_money, t_type=2, t_channel='网上银行',t_str='贷款')
        db.session.add(trans)

        repay_total_money = loan_money * 5 * 0.005 + loan_money  #还款总金额
        repay_month_money = repay_total_money / (5.0*12)
        repay_month_num = 5*12
        loan = Loan(a_id=card_num, loan_total=loan_money, repay_total=repay_total_money, repay_per_month=repay_month_money, repay_month=repay_month_num)
        db.session.add(loan)
        db.session.commit()

        #修改bank表
        loan_bank = Bank.query.filter().first()
        loan_bank.total_money = loan_bank.total_money - loan_money

        #修改accounts表
        loan0 = Loan.query.filter(Loan.a_id == card_num).first()
        id = loan0.l_id
        loan_account = Accounts.query.filter(Accounts.a_id == card_num).first()
        loan_account.l_id = id
        loan_account.balance = loan_account.balance + loan_money
        '''这里需要加上对银行account的修改。根据写代码时候的观察，是不是可以删除分行选项？银行信息好像有一点多余？'''

        db.session.commit()
        return "ok"



if __name__ == '__main__':
    app.run()
