# -*- coding: utf-8 -*-
# from datetime import datetime, date
# import app
# from app import db
# from datetime import datetime
# from passlib.apps import custom_app_context as pwd_context
# from itsdangerous import (TimedJSONWebSignatureSerializer
#                           as Serializer, BadSignature, SignatureExpired)

# class Users(db.Model):
#     """用户"""
#     __tablename__ = 'Users'
#     #__table_args__ = {'mysql_engine': 'InnoDB'}  # 支持事务操作和外键
#     u_id = db.Column(db.String(20), doc = '客户号', primary_key=True)
#     pid = db.Column(db.String(18),doc = '身份证号', nullable=False, unique=True)
#     u_name = db.Column(db.String(10), doc='姓名', nullable=True)
#     u_sex = db.Column(db.Integer, doc='性别', nullable=True)
#     u_birth = db.Column(db.DateTime, doc='出生年月日',  nullable=True)
#     u_tel = db.Column(db.String(11), doc='电话', nullable=True)
#     u_addr = db.Column(db.String(30), doc='住址', nullable=True)
#     u_password = db.Column(db.String(20), doc='密码', nullable=False)
#
# class Bank(db.Model):
#     """银行"""
#     __tablename__ = 'Bank'
#     bk_id = db.Column(db.String(20), doc = '银行号', primary_key=True)
#     bk_name = db.Column(db.String(20),doc = '开户行', nullable=False)
#     total_money = db.Column(db.Float, doc='总金额', nullable=False)
#
#
# class Accounts(db.Model):
#     """账户"""
#     __tablename__ = 'Accounts'
#     a_id = db.Column(db.String(20), doc = '账户号', primary_key=True)
#     u_id = db.Column(db.String(20), db.ForeignKey('Users.id'),doc = '客户号', nullable=False)
#     balance = db.Column(db.Float, doc='余额', nullable=False)
#     a_type = db.Column(db.Integer, doc='账户类型', nullable=False)
#     a_state = db.Column(db.Integer, doc='账户状态',  nullable=False)
#     creation_date = db.Column(db.DateTime, doc='开户时间', default = datetime.now)
#     bk_name = db.Column(db.String(20), db.ForeignKey('Bank.bk_name'),doc='开户行名', nullable=True)
#     l_id = db.Column(db.String(20), doc='贷款号', nullable=True)
#
# class Transaction(db.Model):
#     """交易"""
#     __tablename__ = 'Transaction'
#     t_id = db.Column(db.String(20), doc = '交易号', primary_key=True)
#     hka_id = db.Column(db.String(20), db.ForeignKey('Accounts.a_id'),doc = '汇款方账户号', nullable=False)
#     ska_id = db.Column(db.String(20), db.ForeignKey('Accounts.a_id'),doc = '收款方账户号', nullable=False)
#     t_money = db.Column(db.Float, doc='交易金额', nullable=False)
#     t_time = db.Column(db.DateTime, doc='操作时间', default = datetime.now, nullable=False)
#     t_type = db.Column(db.Integer, doc='交易类型',  nullable=False)
#     t_channel = db.Column(db.String(20), doc='交易渠道', nullable=False)
#     t_str = db.Column(db.String(50),doc='交易备注', nullable=True)
#
#
# class Loan(db.Model):
#     """贷款"""
#     __tablename__ = 'Loan'
#     l_id = db.Column(db.String(20), doc = '贷款号', primary_key=True)
#     a_id = db.Column(db.String(20), db.ForeignKey('Accounts.a_id'),doc = '账户号', nullable=False)
#     loan_total = db.Column(db.Float, doc='贷款总金额', nullable=False)
#     l_start = db.Column(db.DateTime, doc='贷款时间', default = datetime.now, nullable=False)
#     repay_total = db.Column(db.Float, doc='还款总金额',  nullable=False)
#     repay_per_month = db.Column(db.Float, doc='每月还款金额', nullable=False)
#     repay_month = db.Column(db.Integer,doc='还需还款月份', nullable=True)
#
# class FinanceProducts(db.Model):
#     '''理财产品'''
#     _tablename_ = 'FinanceProducts'
#     fp_id = db.Column(db.String(20),doc='理财产品号', primary_key=True)
#     fp_account = db.Column(db.String(20),doc='公司账户号',nullable=False)
#     fp_name = db.Column(db.String(20),doc='理财产品名称',nullable=False)
#     profit = db.Column(db.Float,doc='分红率/（每月）',nullable=False)
#     note = db.Column(db.String(50),doc='备注信息',nullable=True)
#
# class Finance(db.Model):
#     '''理财'''
#     _tablename_ = 'Finance'
#     a_id = db.Column(db.String(20), db.ForeignKey('Accounts.a_id'),doc='账户号', primary_key=True)
#     fp_id = db.Column(db.String(20), db.ForeignKey('FinanceProducts.fp_id'),doc='理财产品号',nullable=False, primary_key=True)
#     f_amount = db.Column(db.Float,doc='本金',nullable=False)
#     t_id = db.Column(db.String(20), db.ForeignKey('Transaction.t_id'), doc = '交易号', nullable=False)
#     f_start = db.Column(db.DateTime,doc='开始投资时间',nullable=False, default = datetime.now)
#     f_income = db.Column(db.Float,doc='累计收益',nullable=False)





